

## Naming "Convention" 
... or kind of naming explaination to help specify which data in a swap we are refering to

In the most generic form, a swap is done with regards to 2 components. 

    - the "TO Swap", the component to be updated and receiving a new value.
    - the "Swap FROM", the component providing the "new" value used to update the "TO Swap" component.

ex: 
the Bike with id B_A has a core with hardware id ha_1. The core module is replaced with a core that has the hardware id ha_3 provided by the Bike with id B_C.

bike1 = Bike.object.get (tk_bike_id = B_A)
bike2 = Bike.object.get (tk_bike_id = B_C)

To Swap:    bike1   ### B_A->ha_1 
Swap From:  bike2   ### B_C->ha_3   

using the ValueSwap class:

swapValue = ValueSwap()
swapValue.to_swap = B_A
swapValue.swap_from = B_C
swapValue.do_swap()

After the swap :

bike1  ### B_A->ha_3 
bike2  ### B_C->ha_1